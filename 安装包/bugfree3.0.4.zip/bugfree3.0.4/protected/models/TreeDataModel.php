<?php
/* 
 *  BugFree is free software under the terms of the FreeBSD License.
 *  @link        http://www.bugfree.org.cn
 *  @package     BugFree
 */

/**
 * Description of TreeDataModel
 *
 * @author youzhao.zxw<swustnjtu@gmail.com>
 * @version 3.0
 */
class TreeDataModel {
    public $name;
    public $open;
    public $nodes;
    public $id;
    public $pId;
    public $isParent;
}
?>
